from flask import *
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/railwaysss'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)

@app.route("/")
def login():
	return render_template("login.html")
	
@app.route("/registration1")
def register():
	return render_template("registration1.html")
	
	
	
class register(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	name=db.Column(db.String)
	id_no=db.Column(db.String)
	email=db.Column(db.String)
	address=db.Column(db.String)
	phone_no=db.Column(db.String)
	proof_no=db.Column(db.String)
	password=db.Column(db.String)
	confirm_password=db.Column(db.String)
	
	def __init__(self,name,id_no,email,address,phone_no,proof_no,password,confirm_password):
		self.name=name
		self.id_no=id_no
		self.email=email
		self.address=address
		self.phone_no=phone_no
		self.proof_no=proof_no
		self.password=password
		self.confirm_password=confirm_password
		
	@app.route("/register_db",methods=["GET","POST"])
	def register_db():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['id_no'] or not request.form['email'] or not request.form['address'] or not request.form['phone_no'] or not request.form['proof_no'] or not request.form['password'] or not request.form['confirm_password']:
				flash("Error")
			else:
				student=register(request.form['name'],request.form['id_no'],request.form['email'],request.form['address'],request.form['phone_no'],request.form['proof_no'],request.form['password'],request.form['confirm_password'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('registration1'))
		return render_template("registration1.html")


if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)


